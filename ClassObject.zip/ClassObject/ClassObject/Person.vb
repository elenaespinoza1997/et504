﻿Public Class Person
    Private fullName As String
    Private age As Integer = 0
    Private weight As Integer = 0

    Public Sub SetAge(ByVal currentAge As Integer)

        age = currentAge


    End Sub
    Public Sub SetName(ByVal currentName As String)

        fullName = currentName


    End Sub
    Public Sub SetWeight(ByVal currentWeight As Integer)

        weight = currentWeight

    End Sub

    Public Function GetAge() As Integer

        Return age

    End Function

    Public Function GetFullName() As String

        Return fullName

    End Function
    Public Function GetWeight() As Integer

        Return weight

    End Function

    Public Function GetYearBorn() As Integer

        If age <= 0 Then

            Return 0

        End If

        Return Date.Today.Year - age
    End Function

    Public Function GetInfo() As String

        Dim info As String = ""

        If fullName IsNot Nothing Then

            info = "Fullname: " & fullName

        End If
        If age > 0 Then

            info = AddCommaIfNeeded(info) & "Age: " & age


        End If
        If weight > 0 Then

            info = AddCommaIfNeeded(info) & "Weight: " & weight


        End If
        If String.IsNullOrEmpty(info) Then

            Return " No information available."


        End If
        Return info
    End Function

    Private Function AddCommaIfNeeded(ByVal info As String) As String

        If Not String.IsNullOrEmpty(info) Then

            info = info & " , "


        End If
        Return info

    End Function
End Class
